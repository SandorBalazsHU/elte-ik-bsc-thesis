## GPU programming - OpenCL practice dependencies

This repository includes the contents of the magical drive T.

### Drive T

Use mount_t.bat to create the virtual drive T in this folder.